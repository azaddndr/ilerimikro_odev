﻿/*
 * Created by SharpDevelop.
 * User: Hamza
 * Date: 18.12.2025
 * Time: 03:34
 */
namespace TivaArayuzGelistirme
{
	partial class MainForm
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		private System.Windows.Forms.Button btnSaatGonder;
		private System.Windows.Forms.TextBox txtSaat;
		private System.Windows.Forms.TextBox txtYazi;
		private System.Windows.Forms.Button btnYaziGonder;
		private System.Windows.Forms.Label lblGelenSaat;
		private System.Windows.Forms.Label lblADC;
		private System.Windows.Forms.Label lblButonDurum;
		private System.IO.Ports.SerialPort serialPort1;
		private System.Windows.Forms.Timer timer1;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.txtSaat = new System.Windows.Forms.TextBox();
			this.btnSaatGonder = new System.Windows.Forms.Button();
			this.txtYazi = new System.Windows.Forms.TextBox();
			this.btnYaziGonder = new System.Windows.Forms.Button();
			this.lblGelenSaat = new System.Windows.Forms.Label();
			this.lblADC = new System.Windows.Forms.Label();
			this.lblButonDurum = new System.Windows.Forms.Label();
			this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
			this.timer1 = new System.Windows.Forms.Timer(this.components);
			this.SuspendLayout();
			// 
			// txtSaat
			// 
			this.txtSaat.Location = new System.Drawing.Point(29, 77);
			this.txtSaat.Name = "txtSaat";
			this.txtSaat.Size = new System.Drawing.Size(123, 22);
			this.txtSaat.TabIndex = 0;
			this.txtSaat.TextChanged += new System.EventHandler(this.TxtSaatTextChanged);
			// 
			// btnSaatGonder
			// 
			this.btnSaatGonder.Location = new System.Drawing.Point(29, 149);
			this.btnSaatGonder.Name = "btnSaatGonder";
			this.btnSaatGonder.Size = new System.Drawing.Size(155, 86);
			this.btnSaatGonder.TabIndex = 1;
			this.btnSaatGonder.Text = "Saat Ayarla";
			this.btnSaatGonder.UseVisualStyleBackColor = true;
			this.btnSaatGonder.Click += new System.EventHandler(this.BtnSaatGonderClick);
			// 
			// txtYazi
			// 
			this.txtYazi.Location = new System.Drawing.Point(226, 73);
			this.txtYazi.MaxLength = 3;
			this.txtYazi.Name = "txtYazi";
			this.txtYazi.Size = new System.Drawing.Size(114, 22);
			this.txtYazi.TabIndex = 2;
			// 
			// btnYaziGonder
			// 
			this.btnYaziGonder.Location = new System.Drawing.Point(215, 135);
			this.btnYaziGonder.Name = "btnYaziGonder";
			this.btnYaziGonder.Size = new System.Drawing.Size(151, 100);
			this.btnYaziGonder.TabIndex = 3;
			this.btnYaziGonder.Text = "Yazı Gonder";
			this.btnYaziGonder.UseVisualStyleBackColor = true;
			this.btnYaziGonder.Click += new System.EventHandler(this.BtnYaziGonderClick);
			// 
			// lblGelenSaat
			// 
			this.lblGelenSaat.Location = new System.Drawing.Point(384, 25);
			this.lblGelenSaat.Name = "lblGelenSaat";
			this.lblGelenSaat.Size = new System.Drawing.Size(100, 23);
			this.lblGelenSaat.TabIndex = 4;
			this.lblGelenSaat.Text = "00:00:00";
			this.lblGelenSaat.Click += new System.EventHandler(this.LblGelenSaatClick);
			// 
			// lblADC
			// 
			this.lblADC.Location = new System.Drawing.Point(116, 263);
			this.lblADC.Name = "lblADC";
			this.lblADC.Size = new System.Drawing.Size(157, 73);
			this.lblADC.TabIndex = 5;
			this.lblADC.Text = "ADC: 0000";
			// 
			// lblButonDurum
			// 
			this.lblButonDurum.Location = new System.Drawing.Point(384, 123);
			this.lblButonDurum.Name = "lblButonDurum";
			this.lblButonDurum.Size = new System.Drawing.Size(100, 23);
			this.lblButonDurum.TabIndex = 6;
			this.lblButonDurum.Text = "Durum: Pasif";
			this.lblButonDurum.Click += new System.EventHandler(this.LblButonDurumClick);
			// 
			// serialPort1
			// 
			this.serialPort1.PortName = "COM17";
			this.serialPort1.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.SerialPort1DataReceived);
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(550, 422);
			this.Controls.Add(this.lblButonDurum);
			this.Controls.Add(this.lblADC);
			this.Controls.Add(this.lblGelenSaat);
			this.Controls.Add(this.btnYaziGonder);
			this.Controls.Add(this.txtYazi);
			this.Controls.Add(this.btnSaatGonder);
			this.Controls.Add(this.txtSaat);
			this.Name = "MainForm";
			this.Text = "TivaArayuzGelistirme";
			this.Load += new System.EventHandler(this.MainFormLoad);
			this.ResumeLayout(false);
			this.PerformLayout();
		}
	}
}