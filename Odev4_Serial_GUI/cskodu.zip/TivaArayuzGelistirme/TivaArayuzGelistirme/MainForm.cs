﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.IO.Ports; // SerialPort kütüphanesi

namespace TivaArayuzGelistirme
{
	public partial class MainForm : Form
	{
		// Ayrıştırma için değişkenler
		string gelenVeri = "";
		
		public MainForm()
		{
			InitializeComponent();
			
			// Çapraz iş parçacığı hatalarını (Cross-thread) yoksay
			// Bu, öğrenci projeleri için en pratik çözümdür.
			Control.CheckForIllegalCrossThreadCalls = false;
		}
		
		// Program açılınca çalışır
		void MainFormLoad(object sender, EventArgs e)
		{
			try {
				// Port kapalıysa aç
				if(!serialPort1.IsOpen) {
					// Port ismini koddan da sabitleyebilirsin veya Properties'den alır
					// serialPort1.PortName = "COM3"; // Gerekirse burayı aç ve portunu yaz
					serialPort1.Open();
				}
			} catch (Exception ex) {
				MessageBox.Show("Port Hatası: " + ex.Message + "\nLütfen Tiva takılı mı kontrol et.");
			}
		}
		
		// SAAT GÖNDER BUTONU
		void BtnSaatGonderClick(object sender, EventArgs e)
{
    // Bu satırı test için ekliyoruz
    MessageBox.Show("Butona Basıldı! Gönderiliyor..."); 

    if(serialPort1.IsOpen) {
        serialPort1.Write("S" + txtSaat.Text + "\n");
    }
}
		
		// YAZI GÖNDER BUTONU
		void BtnYaziGonderClick(object sender, EventArgs e)
		{
			if(serialPort1.IsOpen) {
				// Protokolümüz: 'T' + Yazi + Enter
				string paket = "T" + txtYazi.Text + "\r\n";
				serialPort1.Write(paket);
			}
		}
		
		// TIVA'DAN VERİ GELDİĞİNDE ÇALIŞIR (DataReceived)
		// Bunu bağlamak için: Design ekranında serialPort1'e tıkla, 
		// Sağda 'Events' (Şimşek ikonu) sekmesine gel, DataReceived'e çift tıkla.
		// Veya bu fonksiyonu elle yazdıysan Designer'dan bağlaman gerekir.
		// En garantisi: Designer'a dön, serialPort1'i seç, Events (Şimşek) -> DataReceived çift tıkla.
		void SerialPort1DataReceived(object sender, SerialDataReceivedEventArgs e)
		{
			try {
				// Satırı oku (Enter'a kadar)
				gelenVeri = serialPort1.ReadLine(); 
				// Gelen: D:12:34:56,4095,1
				
				// Başında 'D' var mı? (Veri paketi mi?)
				if(gelenVeri.StartsWith("D:")) {
					// "D:" kısmını at, gerisini virgüllerden böl
					// Parçalar: [0]=Saat, [1]=ADC, [2]=Buton
					string temizVeri = gelenVeri.Substring(2); 
					string[] parcalar = temizVeri.Split(',');
					
					if(parcalar.Length >= 3) {
						// Arayüzü Güncelle
						lblGelenSaat.Text = parcalar[0]; // Saat
						lblADC.Text = parcalar[1];       // ADC
						
						// Buton Durumu (1: Basıldı, 0: Basılmadı)
						if(parcalar[2].Trim() == "1") {
							lblButonDurum.Text = "BUTONA BASILDI!";
							lblButonDurum.BackColor = Color.Red;
							lblButonDurum.ForeColor = Color.White;
						} else {
							lblButonDurum.Text = "Buton Pasif";
							lblButonDurum.BackColor = Color.LightGray;
							lblButonDurum.ForeColor = Color.Black;
						}
					}
				}
			} catch {
				// Hata olursa (örneğin veri bozuk gelirse) yoksay
			}
		}
		
		void PictureBox1Click(object sender, EventArgs e)
		{
			
		}
		
		void LblButonDurumClick(object sender, EventArgs e)
		{
			
		}
		
		void LblGelenSaatClick(object sender, EventArgs e)
		{
			
		}
		
		void TxtSaatTextChanged(object sender, EventArgs e)
		{
			
		}
	}
}